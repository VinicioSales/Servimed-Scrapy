﻿"""
Configurações do pacote config
"""

from .settings import *
from .paths import *
